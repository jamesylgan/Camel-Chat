(*
 *                ,,__
 *     ..  ..   / o._)   ___   ____                _
 *    /--'/--\  \-'||   / _ \ / ___|__ _ _ __ ___ | |
 *   /        \_/ / |  | | | | |   / _` | '_ ` _ \| |
 * .'\  \__\  __.'.'   | |_| | |__| (_| | | | | | | |
 *   )\ |  )\ |         \___/ \____\__,_|_| |_| |_|_|
 *  // \\ // \\
 * ||_  \\|_  \\_    -- two humps are better than one
 * '--' '--'' '--'
 * source: https://github.com/avsm/vagrant-opam/blob/0ba2974e819390764725a0e18e188f455a14d6ac/bootstrap.sh
 *)

(*https://github.com/IBM/wcs-ocaml*)
